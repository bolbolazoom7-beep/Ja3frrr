import {
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  ViewChild,
  inject,
} from '@angular/core';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { ChatState } from '../services/chat-state';

@Component({
  selector: 'app-composer',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [ReactiveFormsModule, MatIconModule],
  template: `
    <div class="relative w-full max-w-3xl mx-auto px-4 pb-4">
      <div
        class="relative flex flex-col rounded-2xl bg-[#1B1B23] border border-white/10 shadow-lg transition-all duration-200 focus-within:border-[#A994F7]/60 focus-within:ring-2 focus-within:ring-[#A994F7]/15"
      >
        <textarea
          #textareaRef
          [formControl]="inputControl"
          (keydown)="handleKeyDown($event)"
          (input)="adjustHeight()"
          rows="1"
          [placeholder]="
            chatState.language() === 'ar'
              ? 'تحدث مع جعفر... (Shift + Enter لسطر جديد)'
              : 'Message Ja3far... (Shift + Enter for new line)'
          "
          class="w-full resize-none bg-transparent px-4 py-3 text-sm md:text-base text-[#E6E4EC] placeholder-[#A6A2B3]/60 focus:outline-none max-h-48 overflow-y-auto leading-relaxed"
          [attr.aria-label]="
            chatState.language() === 'ar' ? 'حقل إدخال الرسالة' : 'Message input field'
          "
        ></textarea>

        <div class="flex items-center justify-between px-3 py-2 border-t border-white/5">
          <div class="flex items-center gap-1.5 text-xs text-[#A6A2B3]">
            <span class="inline-block w-2 h-2 rounded-full" [class]="chatState.config().status === 'connected' ? 'bg-[#8BCFC2]' : 'bg-amber-400'"></span>
            <span class="font-mono text-[11px]">{{ chatState.config().model }}</span>
          </div>

          <div class="flex items-center gap-2">
            @if (chatState.isStreaming()) {
              <button
                type="button"
                (click)="chatState.stopStreaming()"
                class="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 text-xs font-medium border border-rose-500/20 transition-all cursor-pointer"
                [attr.aria-label]="chatState.language() === 'ar' ? 'إيقاف التوليد' : 'Stop generation'"
              >
                <mat-icon style="font-size: 16px; width: 16px; height: 16px;">stop</mat-icon>
                <span>{{ chatState.language() === 'ar' ? 'إيقاف' : 'Stop' }}</span>
              </button>
            } @else {
              <button
                type="button"
                (click)="submit()"
                [disabled]="!hasContent()"
                class="inline-flex items-center justify-center w-8 h-8 rounded-xl bg-[#A994F7] text-[#111116] hover:bg-[#BDB0F9] disabled:opacity-30 disabled:cursor-not-allowed transition-all cursor-pointer shadow-sm active:scale-95"
                [attr.aria-label]="chatState.language() === 'ar' ? 'إرسال الرسالة' : 'Send message'"
              >
                <mat-icon style="font-size: 18px; width: 18px; height: 18px;">
                  {{ chatState.language() === 'ar' ? 'arrow_upward' : 'arrow_upward' }}
                </mat-icon>
              </button>
            }
          </div>
        </div>
      </div>
    </div>
  `,
})
export class Composer {
  chatState = inject(ChatState);
  @ViewChild('textareaRef') textareaRef!: ElementRef<HTMLTextAreaElement>;

  inputControl = new FormControl<string>('', { nonNullable: true });

  hasContent(): boolean {
    return this.inputControl.value.trim().length > 0;
  }

  handleKeyDown(event: KeyboardEvent) {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      this.submit();
    }
  }

  adjustHeight() {
    if (!this.textareaRef) return;
    const el = this.textareaRef.nativeElement;
    el.style.height = 'auto';
    el.style.height = `${Math.min(el.scrollHeight, 180)}px`;
  }

  submit() {
    const val = this.inputControl.value.trim();
    if (!val || this.chatState.isStreaming()) return;

    this.chatState.sendMessage(val);
    this.inputControl.setValue('');
    if (this.textareaRef) {
      this.textareaRef.nativeElement.style.height = 'auto';
    }
  }
}
