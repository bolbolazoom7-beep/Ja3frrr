import {
  ChangeDetectionStrategy,
  Component,
  OnInit,
  inject,
  input,
  output,
  signal,
} from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { ChatState } from '../services/chat-state';
import { NoTrackClient } from '../services/notrack';
import { DiagnosticResult } from '../core/types';

@Component({
  selector: 'app-diagnostics-modal',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    @if (isOpen()) {
      <div
        class="fixed inset-0 z-50 flex items-center justify-center p-4"
      >
        <!-- Accessible Backdrop Button -->
        <button
          type="button"
          class="fixed inset-0 w-full h-full bg-black/70 backdrop-blur-xs border-0 cursor-default"
          (click)="dismiss.emit()"
          [attr.aria-label]="chatState.language() === 'ar' ? 'إغلاق نافذة التشخيص' : 'Close diagnostics modal'"
        ></button>

        <div
          class="relative w-full max-w-lg bg-[#1B1B23] border border-white/10 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh] z-10"
        >
          <!-- Header -->
          <div class="flex items-center justify-between px-6 py-4 border-b border-white/5">
            <div class="flex items-center gap-2">
              <mat-icon class="text-[#8BCFC2]">troubleshoot</mat-icon>
              <h2 class="font-ruqaa text-xl font-bold text-white">
                {{ chatState.language() === 'ar' ? 'تشخيص نظام جعفر' : 'System Diagnostics' }}
              </h2>
            </div>
            <button
              type="button"
              (click)="dismiss.emit()"
              class="p-1 rounded-lg text-[#A6A2B3] hover:text-white hover:bg-white/5 transition-colors cursor-pointer"
              [attr.aria-label]="chatState.language() === 'ar' ? 'إغلاق' : 'Close'"
            >
              <mat-icon style="font-size: 20px;">close</mat-icon>
            </button>
          </div>

          <!-- Content -->
          <div class="flex-1 overflow-y-auto px-6 py-5 space-y-4 text-xs">
            <!-- Summary Status -->
            <div class="p-3.5 rounded-xl bg-[#16161D] border border-white/5 space-y-2.5">
              <div class="flex items-center justify-between pb-2 border-b border-white/5">
                <span class="text-[#A6A2B3]">{{ chatState.language() === 'ar' ? 'حالة الواجهة (Frontend)' : 'Frontend App' }}</span>
                <span class="flex items-center gap-1 text-[#8BCFC2] font-medium">
                  <span class="w-2 h-2 rounded-full bg-[#8BCFC2]"></span>
                  <span>متصل (Angular v21 Zoneless)</span>
                </span>
              </div>

              <div class="flex items-center justify-between pb-2 border-b border-white/5">
                <span class="text-[#A6A2B3]">{{ chatState.language() === 'ar' ? 'الخادم الداخلي (Express)' : 'Backend Server' }}</span>
                <span class="flex items-center gap-1 text-[#8BCFC2] font-medium">
                  <span class="w-2 h-2 rounded-full bg-[#8BCFC2]"></span>
                  <span>يعمل بـ Node.js SSR</span>
                </span>
              </div>

              <div class="flex items-center justify-between pb-2 border-b border-white/5">
                <span class="text-[#A6A2B3]">{{ chatState.language() === 'ar' ? 'مزود NoTrack.ai' : 'NoTrack.ai API' }}</span>
                <span class="flex items-center gap-1 font-medium" [class]="status()?.notrackOk ? 'text-[#8BCFC2]' : 'text-amber-400'">
                  <span class="w-2 h-2 rounded-full" [class]="status()?.notrackOk ? 'bg-[#8BCFC2]' : 'bg-amber-400'"></span>
                  <span>{{ status()?.notrackOk ? 'متصل وجاهز' : 'قيد الاختبار / غير مؤكد' }}</span>
                </span>
              </div>

              <div class="flex items-center justify-between">
                <span class="text-[#A6A2B3]">{{ chatState.language() === 'ar' ? 'زمن الاستجابة (Latency)' : 'Latency' }}</span>
                <span class="font-mono text-[#E6E4EC]">
                  {{ status()?.latencyMs ? status()?.latencyMs + ' ms' : '---' }}
                </span>
              </div>
            </div>

            <!-- Privacy & Architecture details -->
            <div class="p-3.5 rounded-xl bg-[#16161D] border border-white/5 space-y-2">
              <h4 class="font-medium text-[#A994F7] flex items-center gap-1">
                <mat-icon style="font-size: 16px;">security</mat-icon>
                <span>{{ chatState.language() === 'ar' ? 'الأمان والخصوصية' : 'Security & Privacy' }}</span>
              </h4>
              <p class="text-[#A6A2B3] leading-relaxed">
                {{ chatState.language() === 'ar'
                  ? 'يعتمد نظام NoTrack.ai على بنية عديمة الحالة (Stateless) لا تحفظ أي سجلات أو محادثات على خوادم المزود. المفاتيح مشفرة ومحفوظة خلف وكيل خادم التطبيق، والروابط تخضع لحماية SSRF صارمة.'
                  : 'NoTrack.ai operates on a zero-log, stateless architecture. All requests are proxied securely with SSRF defense and masked credential handling.'
                }}
              </p>
            </div>

            <!-- Sanitized Report Details -->
            <div class="p-3 rounded-xl bg-[#111116] border border-white/5">
              <div class="flex items-center justify-between mb-2">
                <span class="font-mono text-[11px] text-[#A6A2B3]">تقرير التشخيص الفني:</span>
                <button
                  type="button"
                  (click)="copyReport()"
                  class="text-[11px] text-[#A994F7] hover:underline cursor-pointer"
                >
                  {{ copied() ? 'تم النسخ!' : 'نسخ التقرير' }}
                </button>
              </div>
              <pre class="font-mono text-[10px] text-[#A6A2B3] overflow-x-auto p-2 bg-[#16161D] rounded-lg leading-relaxed">{{ diagnosticReport() }}</pre>
            </div>
          </div>

          <!-- Footer -->
          <div class="flex items-center justify-between px-6 py-4 border-t border-white/5 bg-[#16161D]/50">
            <button
              type="button"
              (click)="retest()"
              [disabled]="testing()"
              class="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-white font-medium text-xs border border-white/10 transition-all cursor-pointer disabled:opacity-50"
            >
              <mat-icon style="font-size: 16px;" [class.animate-spin]="testing()">refresh</mat-icon>
              <span>{{ chatState.language() === 'ar' ? 'إعادة الفحص' : 'Re-check' }}</span>
            </button>

            <button
              type="button"
              (click)="dismiss.emit()"
              class="px-4 py-2 rounded-xl bg-[#A994F7] hover:bg-[#BDB0F9] text-[#111116] font-medium text-xs transition-all cursor-pointer"
            >
              {{ chatState.language() === 'ar' ? 'إغلاق' : 'Close' }}
            </button>
          </div>
        </div>
      </div>
    }
  `,
})
export class DiagnosticsModal implements OnInit {
  chatState = inject(ChatState);
  notrack = inject(NoTrackClient);

  isOpen = input<boolean>(false);
  dismiss = output<void>();

  status = signal<DiagnosticResult | null>(null);
  testing = signal<boolean>(false);
  copied = signal<boolean>(false);

  ngOnInit() {
    this.retest();
  }

  async retest() {
    this.testing.set(true);
    try {
      const res = await this.notrack.testConnection();
      this.status.set(res);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      this.status.set({
        frontendOk: true,
        backendOk: true,
        notrackOk: false,
        statusMessage: msg,
        timestamp: Date.now(),
        activeModel: this.chatState.config().model,
        version: '1.0.0-ja3far',
      });
    } finally {
      this.testing.set(false);
    }
  }

  diagnosticReport(): string {
    const s = this.status();
    const cfg = this.chatState.config();
    return JSON.stringify(
      {
        product: 'Ja3far AI (جعفر)',
        version: '1.0.0',
        environment: 'Cloud Run / Node SSR',
        clientZoneless: true,
        provider: 'NoTrack.ai (OpenAI-compatible)',
        baseUrl: cfg.baseUrl,
        model: cfg.model,
        keyMasked: cfg.apiKeyMasked,
        lastTestStatus: s?.statusMessage,
        latencyMs: s?.latencyMs,
        providerOk: s?.notrackOk,
        timestamp: new Date().toISOString(),
      },
      null,
      2
    );
  }

  async copyReport() {
    if (typeof navigator !== 'undefined' && navigator.clipboard) {
      await navigator.clipboard.writeText(this.diagnosticReport());
      this.copied.set(true);
      setTimeout(() => this.copied.set(false), 2000);
    }
  }
}
