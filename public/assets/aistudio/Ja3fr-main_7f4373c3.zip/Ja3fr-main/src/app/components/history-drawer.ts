import {
  ChangeDetectionStrategy,
  Component,
  inject,
  input,
  output,
} from '@angular/core';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { ChatState } from '../services/chat-state';

@Component({
  selector: 'app-history-drawer',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [ReactiveFormsModule, MatIconModule],
  template: `
    <!-- Backdrop for all viewports when drawer is open -->
    @if (isOpen()) {
      <button
        type="button"
        class="fixed inset-0 w-full h-full bg-black/60 backdrop-blur-xs z-40 border-0 cursor-default"
        (click)="dismiss.emit()"
        [attr.aria-label]="chatState.language() === 'ar' ? 'إغلاق القائمة الجانبية' : 'Close side menu'"
      ></button>
    }

    <!-- Drawer container -->
    <aside
      class="fixed top-0 bottom-0 z-50 flex flex-col w-72 md:w-80 bg-[#16161D] border-x border-white/10 shadow-2xl transition-transform duration-300 ease-in-out"
      [class]="
        chatState.language() === 'ar'
          ? (isOpen() ? 'right-0 translate-x-0' : 'right-0 translate-x-full')
          : (isOpen() ? 'left-0 translate-x-0' : 'left-0 -translate-x-full')
      "
    >
      <!-- Drawer Header -->
      <div class="flex items-center justify-between p-4 border-b border-white/5">
        <div class="flex items-center gap-2">
          <span class="font-ruqaa text-xl text-[#A994F7] font-bold">سجل المحادثات</span>
        </div>
        <div class="flex items-center gap-1">
          <button
            type="button"
            (click)="dismiss.emit()"
            class="p-1.5 rounded-lg text-[#A6A2B3] hover:text-white hover:bg-white/5 md:hidden cursor-pointer"
            [attr.aria-label]="chatState.language() === 'ar' ? 'إغلاق القائمة' : 'Close drawer'"
          >
            <mat-icon style="font-size: 20px;">close</mat-icon>
          </button>
        </div>
      </div>

      <!-- New Chat Button -->
      <div class="p-3">
        <button
          type="button"
          (click)="onNewChat()"
          class="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-[#A994F7]/20 to-[#8BCFC2]/20 hover:from-[#A994F7]/30 hover:to-[#8BCFC2]/30 text-white font-medium text-sm border border-[#A994F7]/30 transition-all cursor-pointer shadow-sm active:scale-[0.98]"
        >
          <mat-icon style="font-size: 18px;">add</mat-icon>
          <span>{{ chatState.language() === 'ar' ? 'محادثة جديدة' : 'New Conversation' }}</span>
        </button>
      </div>

      <!-- Search Input -->
      <div class="px-3 pb-2">
        <div class="relative">
          <input
            [formControl]="searchControl"
            (input)="onSearchChange()"
            type="text"
            [placeholder]="chatState.language() === 'ar' ? 'بحث في المحادثات...' : 'Search conversations...'"
            class="w-full bg-[#1B1B23] border border-white/5 rounded-xl py-2 px-8 text-xs text-[#E6E4EC] placeholder-[#A6A2B3]/50 focus:outline-none focus:border-[#A994F7]/50"
            [attr.aria-label]="chatState.language() === 'ar' ? 'بحث في المحادثات' : 'Search conversations'"
          />
          <mat-icon
            class="absolute top-2 text-[#A6A2B3] pointer-events-none"
            [class]="chatState.language() === 'ar' ? 'right-2.5' : 'left-2.5'"
            style="font-size: 16px;"
          >
            search
          </mat-icon>
        </div>
      </div>

      <!-- Conversations List -->
      <div class="flex-1 overflow-y-auto px-2 py-1 space-y-1">
        @if (chatState.filteredConversations().length === 0) {
          <div class="py-12 text-center text-xs text-[#A6A2B3]">
            {{ chatState.language() === 'ar' ? 'لا توجد محادثات سابقة' : 'No conversations found' }}
          </div>
        } @else {
          @for (conv of chatState.filteredConversations(); track conv.id) {
            <div
              class="group relative flex items-center justify-between px-3 py-2.5 rounded-xl text-xs md:text-sm cursor-pointer transition-all border"
              [class]="
                conv.id === chatState.currentConversationId()
                  ? 'bg-[#1B1B23] text-white border-[#A994F7]/40 shadow-xs'
                  : 'text-[#A6A2B3] hover:text-[#E6E4EC] hover:bg-white/5 border-transparent'
              "
            >
              <button
                type="button"
                class="flex items-center gap-2 overflow-hidden flex-1 text-right bg-transparent border-0 cursor-pointer p-0 text-inherit focus:outline-none"
                (click)="selectChat(conv.id)"
              >
                <mat-icon style="font-size: 16px; width: 16px; height: 16px;" class="shrink-0 text-[#A994F7]/70">
                  chat_bubble_outline
                </mat-icon>
                <span class="truncate font-medium">{{ conv.title }}</span>
              </button>

              <!-- Delete actions on hover -->
              <div class="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                <button
                  type="button"
                  (click)="deleteChat($event, conv.id)"
                  class="p-1 rounded text-[#A6A2B3] hover:text-rose-400 hover:bg-white/10 transition-colors"
                  [attr.title]="chatState.language() === 'ar' ? 'حذف' : 'Delete'"
                  [attr.aria-label]="chatState.language() === 'ar' ? 'حذف المحادثة' : 'Delete conversation'"
                >
                  <mat-icon style="font-size: 14px; width: 14px; height: 14px;">delete_outline</mat-icon>
                </button>
              </div>
            </div>
          }
        }
      </div>

      <!-- Drawer Footer -->
      <div class="p-3 border-t border-white/5 flex items-center justify-between text-xs text-[#A6A2B3]">
        <button
          type="button"
          (click)="exportData()"
          class="inline-flex items-center gap-1 hover:text-white transition-colors cursor-pointer"
          [attr.title]="chatState.language() === 'ar' ? 'تصدير نسخة احتياطية' : 'Export backup'"
        >
          <mat-icon style="font-size: 15px;">download</mat-icon>
          <span>{{ chatState.language() === 'ar' ? 'تصدير' : 'Export' }}</span>
        </button>

        <button
          type="button"
          (click)="clearAll()"
          class="inline-flex items-center gap-1 text-rose-400/80 hover:text-rose-400 transition-colors cursor-pointer"
          [attr.title]="chatState.language() === 'ar' ? 'مسح كل المحادثات' : 'Clear all'"
        >
          <mat-icon style="font-size: 15px;">delete_sweep</mat-icon>
          <span>{{ chatState.language() === 'ar' ? 'مسح الكل' : 'Clear All' }}</span>
        </button>
      </div>
    </aside>
  `,
})
export class HistoryDrawer {
  chatState = inject(ChatState);
  isOpen = input<boolean>(false);
  dismiss = output<void>();

  searchControl = new FormControl<string>('', { nonNullable: true });

  onSearchChange() {
    this.chatState.searchQuery.set(this.searchControl.value);
  }

  onNewChat() {
    this.chatState.startNewConversation();
    this.dismiss.emit();
  }

  selectChat(id: string) {
    this.chatState.selectConversation(id);
    this.dismiss.emit();
  }

  deleteChat(event: MouseEvent, id: string) {
    event.stopPropagation();
    const isAr = this.chatState.language() === 'ar';
    if (confirm(isAr ? 'هل أنت متأكد من حذف هذه المحادثة؟' : 'Delete this conversation?')) {
      this.chatState.deleteConversation(id);
    }
  }

  clearAll() {
    const isAr = this.chatState.language() === 'ar';
    if (confirm(isAr ? 'هل أنت متأكد من مسح جميع المحادثات نهائياً؟' : 'Permanently clear all chat history?')) {
      this.chatState.clearAllConversations();
    }
  }

  exportData() {
    const jsonStr = this.chatState.exportDataJson();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ja3far_conversations_${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }
}
