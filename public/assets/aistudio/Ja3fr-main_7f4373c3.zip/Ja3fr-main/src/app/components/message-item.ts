import {
  ChangeDetectionStrategy,
  Component,
  input,
  signal,
  inject,
} from '@angular/core';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { ChatMessage } from '../core/types';
import { parseMarkdown } from '../core/markdown-parser';
import { ChatState } from '../services/chat-state';

@Component({
  selector: 'app-message-item',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [ReactiveFormsModule, MatIconModule],
  template: `
    <div
      class="group w-full max-w-3xl mx-auto px-4 py-3 flex gap-3 transition-colors"
      [class]="message().role === 'user' ? 'justify-end' : 'justify-start'"
    >
      <!-- Assistant Avatar -->
      @if (message().role === 'assistant') {
        <div
          class="shrink-0 w-8 h-8 rounded-xl bg-gradient-to-br from-[#A994F7] to-[#8BCFC2] p-[1px] flex items-center justify-center shadow-sm"
        >
          <div class="w-full h-full bg-[#1B1B23] rounded-[11px] flex items-center justify-center">
            <span class="font-ruqaa text-[#A994F7] font-bold text-sm select-none">ج</span>
          </div>
        </div>
      }

      <div
        class="flex flex-col gap-1.5 max-w-[85%] md:max-w-[78%]"
        [class]="message().role === 'user' ? 'items-end' : 'items-start'"
      >
        <!-- User Bubble or Assistant Content -->
        @if (message().role === 'user') {
          @if (isEditing()) {
            <div class="w-full min-w-[280px] flex flex-col gap-2 p-3 bg-[#1B1B23] rounded-2xl border border-[#A994F7]/40">
              <textarea
                [formControl]="editControl"
                rows="2"
                class="w-full bg-transparent text-sm text-[#E6E4EC] focus:outline-none resize-none leading-relaxed"
                [attr.aria-label]="chatState.language() === 'ar' ? 'تعديل الرسالة' : 'Edit message'"
              ></textarea>
              <div class="flex items-center justify-end gap-2 text-xs">
                <button
                  type="button"
                  (click)="cancelEdit()"
                  class="px-2.5 py-1 rounded-lg text-[#A6A2B3] hover:bg-white/5 transition-colors cursor-pointer"
                >
                  {{ chatState.language() === 'ar' ? 'إلغاء' : 'Cancel' }}
                </button>
                <button
                  type="button"
                  (click)="saveEdit()"
                  class="px-3 py-1 rounded-lg bg-[#A994F7] text-[#111116] font-medium hover:bg-[#BDB0F9] transition-colors cursor-pointer"
                >
                  {{ chatState.language() === 'ar' ? 'حفظ وإرسال' : 'Save & Send' }}
                </button>
              </div>
            </div>
          } @else {
            <div
              class="px-4 py-2.5 rounded-2xl bg-[#A994F7]/15 border border-[#A994F7]/25 text-[#E6E4EC] text-sm md:text-base leading-relaxed break-words"
            >
              {{ message().content }}
            </div>
          }
        } @else {
          <!-- Assistant Message Body -->
          <div
            class="px-4 py-3 rounded-2xl bg-[#1B1B23] border border-white/5 text-[#E6E4EC] shadow-sm w-full overflow-hidden"
          >
            @if (message().status === 'error') {
              <div class="p-3 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-300 text-xs md:text-sm flex flex-col gap-1.5">
                <div class="flex items-center gap-1.5 font-medium">
                  <mat-icon style="font-size: 16px; width: 16px; height: 16px;">error_outline</mat-icon>
                  <span>{{ message().errorCategory || 'خطأ في المعالجة' }}</span>
                </div>
                <p class="text-rose-200/90 leading-relaxed">{{ message().errorMessage }}</p>
                <div class="mt-1">
                  <button
                    type="button"
                    (click)="retry()"
                    class="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-rose-500/20 hover:bg-rose-500/30 text-rose-100 text-xs transition-colors cursor-pointer"
                  >
                    <mat-icon style="font-size: 14px; width: 14px; height: 14px;">replay</mat-icon>
                    <span>{{ chatState.language() === 'ar' ? 'إعادة المحاولة' : 'Retry' }}</span>
                  </button>
                </div>
              </div>
            } @else {
              @if (message().content.length === 0 && message().status === 'streaming') {
                <div class="flex items-center gap-1.5 py-1 text-[#A994F7]">
                  <span class="w-2 h-2 rounded-full bg-[#A994F7] animate-pulse"></span>
                  <span class="w-2 h-2 rounded-full bg-[#8BCFC2] animate-pulse delay-150"></span>
                  <span class="w-2 h-2 rounded-full bg-[#A994F7] animate-pulse delay-300"></span>
                </div>
              } @else {
                <div
                  class="markdown-content prose-invert max-w-none break-words"
                  [innerHTML]="renderedHtml()"
                  (click)="handleContentClick($event)"
                  (keydown.enter)="handleContentClick($event)"
                  tabindex="0"
                  role="region"
                  [attr.aria-label]="chatState.language() === 'ar' ? 'محتوى الرسالة' : 'Message content'"
                ></div>
              }
            }
          </div>
        }

        <!-- Actions Row -->
        <div
          class="flex items-center gap-1.5 opacity-80 group-hover:opacity-100 transition-opacity text-xs text-[#A6A2B3] px-1"
        >
          @if (message().role === 'user') {
            @if (!isEditing()) {
              <button
                type="button"
                (click)="startEdit()"
                class="p-1 rounded hover:text-white hover:bg-white/5 transition-colors cursor-pointer"
                [attr.title]="chatState.language() === 'ar' ? 'تعديل' : 'Edit'"
                [attr.aria-label]="chatState.language() === 'ar' ? 'تعديل الرسالة' : 'Edit message'"
              >
                <mat-icon style="font-size: 14px; width: 14px; height: 14px;">edit</mat-icon>
              </button>
            }
          } @else {
            <button
              type="button"
              (click)="copyMessage()"
              class="inline-flex items-center gap-1 p-1 rounded hover:text-white hover:bg-white/5 transition-colors cursor-pointer"
              [attr.title]="chatState.language() === 'ar' ? 'نسخ الإجابة' : 'Copy answer'"
              [attr.aria-label]="chatState.language() === 'ar' ? 'نسخ الإجابة' : 'Copy answer'"
            >
              <mat-icon style="font-size: 14px; width: 14px; height: 14px;">
                {{ isCopied() ? 'check' : 'content_copy' }}
              </mat-icon>
              @if (isCopied()) {
                <span class="text-[10px] text-[#8BCFC2]">
                  {{ chatState.language() === 'ar' ? 'تم النسخ' : 'Copied' }}
                </span>
              }
            </button>

            @if (message().status === 'complete') {
              <button
                type="button"
                (click)="regenerate()"
                class="inline-flex items-center gap-1 p-1 rounded hover:text-white hover:bg-white/5 transition-colors cursor-pointer"
                [attr.title]="chatState.language() === 'ar' ? 'إعادة التوليد' : 'Regenerate'"
                [attr.aria-label]="chatState.language() === 'ar' ? 'إعادة التوليد' : 'Regenerate'"
              >
                <mat-icon style="font-size: 14px; width: 14px; height: 14px;">refresh</mat-icon>
              </button>
            }
          }
        </div>
      </div>
    </div>
  `,
})
export class MessageItem {
  chatState = inject(ChatState);
  message = input.required<ChatMessage>();

  isEditing = signal<boolean>(false);
  isCopied = signal<boolean>(false);
  editControl = new FormControl<string>('', { nonNullable: true });

  renderedHtml(): string {
    return parseMarkdown(this.message().content);
  }

  startEdit() {
    this.editControl.setValue(this.message().content);
    this.isEditing.set(true);
  }

  cancelEdit() {
    this.isEditing.set(false);
  }

  saveEdit() {
    const val = this.editControl.value.trim();
    if (!val) return;
    this.isEditing.set(false);
    this.chatState.editAndResend(this.message().id, val);
  }

  retry() {
    this.chatState.regenerateResponse(this.message().id);
  }

  regenerate() {
    this.chatState.regenerateResponse(this.message().id);
  }

  async copyMessage() {
    if (typeof navigator !== 'undefined' && navigator.clipboard) {
      await navigator.clipboard.writeText(this.message().content);
      this.isCopied.set(true);
      setTimeout(() => this.isCopied.set(false), 2000);
    }
  }

  handleContentClick(event: Event) {
    const target = (event.target as HTMLElement).closest('.copy-code-btn') as HTMLElement;
    if (target) {
      const code = target.getAttribute('data-code');
      if (code && typeof navigator !== 'undefined' && navigator.clipboard) {
        navigator.clipboard.writeText(decodeURIComponent(code));
        const span = target.querySelector('span:last-child');
        if (span) {
          const prev = span.textContent;
          span.textContent = this.chatState.language() === 'ar' ? 'تم!' : 'Done!';
          setTimeout(() => {
            span.textContent = prev;
          }, 1500);
        }
      }
    }
  }
}
