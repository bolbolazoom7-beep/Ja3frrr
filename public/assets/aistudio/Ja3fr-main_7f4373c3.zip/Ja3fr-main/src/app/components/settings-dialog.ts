import {
  ChangeDetectionStrategy,
  Component,
  OnInit,
  inject,
  input,
  output,
  signal,
} from '@angular/core';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { ChatState } from '../services/chat-state';
import { NoTrackClient } from '../services/notrack';
import { validateApiUrl } from '../core/url-validator';

@Component({
  selector: 'app-settings-dialog',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [ReactiveFormsModule, MatIconModule],
  template: `
    @if (isOpen()) {
      <div
        class="fixed inset-0 z-50 flex items-center justify-center p-4 animate-in fade-in duration-200"
      >
        <!-- Accessible Backdrop Button -->
        <button
          type="button"
          class="fixed inset-0 w-full h-full bg-black/70 backdrop-blur-xs border-0 cursor-default"
          (click)="dismiss.emit()"
          [attr.aria-label]="chatState.language() === 'ar' ? 'إغلاق نافذة الإعدادات' : 'Close settings modal'"
        ></button>

        <div
          class="relative w-full max-w-lg bg-[#1B1B23] border border-white/10 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh] z-10"
        >
          <!-- Header -->
          <div class="flex items-center justify-between px-6 py-4 border-b border-white/5">
            <div class="flex items-center gap-2">
              <mat-icon class="text-[#A994F7]">settings</mat-icon>
              <h2 class="font-ruqaa text-xl font-bold text-white">
                {{ chatState.language() === 'ar' ? 'إعدادات جعفر' : 'Ja3far Settings' }}
              </h2>
            </div>
            <button
              type="button"
              (click)="dismiss.emit()"
              class="p-1 rounded-lg text-[#A6A2B3] hover:text-white hover:bg-white/5 transition-colors cursor-pointer"
              [attr.aria-label]="chatState.language() === 'ar' ? 'إغلاق' : 'Close'"
            >
              <mat-icon style="font-size: 20px;">close</mat-icon>
            </button>
          </div>

          <!-- Body -->
          <div class="flex-1 overflow-y-auto px-6 py-5 space-y-6 text-sm">
            <!-- 1. Language & Theme -->
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <!-- Language -->
              <div class="flex flex-col gap-2">
                <span class="text-xs font-medium text-[#A6A2B3]">
                  {{ chatState.language() === 'ar' ? 'اللغة / Language' : 'Language' }}
                </span>
                <div class="grid grid-cols-2 gap-1 p-1 bg-[#16161D] rounded-xl border border-white/5">
                  <button
                    type="button"
                    (click)="chatState.setLanguage('ar')"
                    class="py-1.5 px-3 rounded-lg text-xs font-medium transition-all cursor-pointer"
                    [class]="chatState.language() === 'ar' ? 'bg-[#A994F7] text-[#111116] shadow-xs' : 'text-[#A6A2B3] hover:text-white'"
                  >
                    العربية
                  </button>
                  <button
                    type="button"
                    (click)="chatState.setLanguage('en')"
                    class="py-1.5 px-3 rounded-lg text-xs font-medium transition-all cursor-pointer"
                    [class]="chatState.language() === 'en' ? 'bg-[#A994F7] text-[#111116] shadow-xs' : 'text-[#A6A2B3] hover:text-white'"
                  >
                    English
                  </button>
                </div>
              </div>

              <!-- Theme -->
              <div class="flex flex-col gap-2">
                <span class="text-xs font-medium text-[#A6A2B3]">
                  {{ chatState.language() === 'ar' ? 'المظهر (Theme)' : 'Theme' }}
                </span>
                <div class="grid grid-cols-3 gap-1 p-1 bg-[#16161D] rounded-xl border border-white/5">
                  <button
                    type="button"
                    (click)="chatState.setTheme('dark')"
                    class="py-1.5 px-2 rounded-lg text-xs font-medium transition-all cursor-pointer"
                    [class]="chatState.theme() === 'dark' ? 'bg-[#A994F7] text-[#111116] shadow-xs' : 'text-[#A6A2B3] hover:text-white'"
                  >
                    {{ chatState.language() === 'ar' ? 'داكن' : 'Dark' }}
                  </button>
                  <button
                    type="button"
                    (click)="chatState.setTheme('light')"
                    class="py-1.5 px-2 rounded-lg text-xs font-medium transition-all cursor-pointer"
                    [class]="chatState.theme() === 'light' ? 'bg-[#A994F7] text-[#111116] shadow-xs' : 'text-[#A6A2B3] hover:text-white'"
                  >
                    {{ chatState.language() === 'ar' ? 'فاتح' : 'Light' }}
                  </button>
                  <button
                    type="button"
                    (click)="chatState.setTheme('system')"
                    class="py-1.5 px-2 rounded-lg text-xs font-medium transition-all cursor-pointer"
                    [class]="chatState.theme() === 'system' ? 'bg-[#A994F7] text-[#111116] shadow-xs' : 'text-[#A6A2B3] hover:text-white'"
                  >
                    {{ chatState.language() === 'ar' ? 'تلقائي' : 'Auto' }}
                  </button>
                </div>
              </div>
            </div>

            <!-- Divider -->
            <div class="border-t border-white/5"></div>

            <!-- 2. NoTrack.ai API Configuration -->
            <div class="space-y-4">
              <div class="flex items-center justify-between">
                <div>
                  <h3 class="font-medium text-white flex items-center gap-1.5">
                    <span>{{ chatState.language() === 'ar' ? 'اتصال NoTrack.ai' : 'NoTrack.ai Connection' }}</span>
                    <span class="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-mono bg-[#8BCFC2]/15 text-[#8BCFC2] border border-[#8BCFC2]/30">
                      OpenAI Protocol
                    </span>
                  </h3>
                  <p class="text-xs text-[#A6A2B3] mt-0.5">
                    {{ chatState.language() === 'ar' ? 'المزود المعتمد فائق الخصوصية بدون تتبع أو سجلات.' : 'Verified zero-tracking, privacy-first AI backend.' }}
                  </p>
                </div>
              </div>

              <!-- Base URL -->
              <div class="space-y-1.5">
                <label for="baseUrlInput" class="text-xs font-medium text-[#A6A2B3]">
                  {{ chatState.language() === 'ar' ? 'رابط خادم NoTrack (Base URL)' : 'Base URL' }}
                </label>
                <input
                  id="baseUrlInput"
                  [formControl]="baseUrlControl"
                  type="url"
                  placeholder="https://api.notrack.ai/v1"
                  class="w-full bg-[#16161D] border border-white/10 rounded-xl px-3.5 py-2 text-xs font-mono text-[#E6E4EC] focus:outline-none focus:border-[#A994F7]/60"
                />
              </div>

              <!-- Model Identifier -->
              <div class="space-y-1.5">
                <label for="modelInput" class="text-xs font-medium text-[#A6A2B3]">
                  {{ chatState.language() === 'ar' ? 'معرف النموذج (Model ID)' : 'Model ID' }}
                </label>
                <input
                  id="modelInput"
                  [formControl]="modelControl"
                  type="text"
                  placeholder="notrack-uncensored"
                  class="w-full bg-[#16161D] border border-white/10 rounded-xl px-3.5 py-2 text-xs font-mono text-[#E6E4EC] focus:outline-none focus:border-[#A994F7]/60"
                />
              </div>

              <!-- API Key -->
              <div class="space-y-1.5">
                <div class="flex items-center justify-between">
                  <label for="apiKeyInput" class="text-xs font-medium text-[#A6A2B3]">
                    {{ chatState.language() === 'ar' ? 'مفتاح NoTrack API' : 'NoTrack API Key' }}
                  </label>
                  @if (chatState.config().apiKeyMasked) {
                    <span class="text-[11px] font-mono text-[#8BCFC2]">
                      {{ chatState.config().apiKeyMasked }}
                    </span>
                  }
                </div>
                <input
                  id="apiKeyInput"
                  [formControl]="apiKeyControl"
                  type="password"
                  placeholder="اتركه فارغاً للإبقاء على المفتاح الحالي المكوّن"
                  class="w-full bg-[#16161D] border border-white/10 rounded-xl px-3.5 py-2 text-xs font-mono text-[#E6E4EC] focus:outline-none focus:border-[#A994F7]/60"
                />
                <p class="text-[11px] text-[#A6A2B3]/70">
                  {{ chatState.language() === 'ar' ? 'المفتاح محمي ومخزن في الخادم الداخلي ولا يظهر في الكود المصدري للواجهة.' : 'The API key is securely handled on the backend server.' }}
                </p>
              </div>

              <!-- Test Connection Result Banner -->
              @if (testResult(); as res) {
                <div
                  class="p-3 rounded-xl border text-xs flex flex-col gap-1"
                  [class]="res.notrackOk ? 'bg-[#8BCFC2]/10 border-[#8BCFC2]/30 text-[#8BCFC2]' : 'bg-rose-500/10 border-rose-500/30 text-rose-300'"
                >
                  <div class="flex items-center justify-between font-medium">
                    <span class="flex items-center gap-1">
                      <mat-icon style="font-size: 16px; width: 16px; height: 16px;">
                        {{ res.notrackOk ? 'check_circle' : 'error' }}
                      </mat-icon>
                      <span>{{ res.statusMessage }}</span>
                    </span>
                    @if (res.latencyMs) {
                      <span class="font-mono text-[11px]">{{ res.latencyMs }}ms</span>
                    }
                  </div>
                </div>
              }
            </div>
          </div>

          <!-- Footer Actions -->
          <div class="flex items-center justify-between px-6 py-4 border-t border-white/5 bg-[#16161D]/50">
            <div class="flex items-center gap-2">
              <button
                type="button"
                (click)="runConnectionTest()"
                [disabled]="isTesting()"
                class="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-[#E6E4EC] text-xs font-medium border border-white/10 transition-all cursor-pointer disabled:opacity-50"
              >
                <mat-icon style="font-size: 16px;" [class.animate-spin]="isTesting()">
                  {{ isTesting() ? 'sync' : 'network_check' }}
                </mat-icon>
                <span>{{ chatState.language() === 'ar' ? 'اختبار الاتصال' : 'Test Connection' }}</span>
              </button>

              <button
                type="button"
                (click)="resetDefaults()"
                class="px-2.5 py-2 text-xs text-[#A6A2B3] hover:text-white transition-colors cursor-pointer"
              >
                {{ chatState.language() === 'ar' ? 'استعادة الافتراضي' : 'Reset' }}
              </button>
            </div>

            <div class="flex items-center gap-2">
              <button
                type="button"
                (click)="dismiss.emit()"
                class="px-3.5 py-2 text-xs text-[#A6A2B3] hover:text-white transition-colors cursor-pointer"
              >
                {{ chatState.language() === 'ar' ? 'إلغاء' : 'Cancel' }}
              </button>
              <button
                type="button"
                (click)="saveConfig()"
                [disabled]="isSaving()"
                class="px-4 py-2 rounded-xl bg-[#A994F7] hover:bg-[#BDB0F9] text-[#111116] font-medium text-xs shadow-sm transition-all cursor-pointer disabled:opacity-50"
              >
                {{ chatState.language() === 'ar' ? 'حفظ الإعدادات' : 'Save Changes' }}
              </button>
            </div>
          </div>
        </div>
      </div>
    }
  `,
})
export class SettingsDialog implements OnInit {
  chatState = inject(ChatState);
  notrack = inject(NoTrackClient);

  isOpen = input<boolean>(false);
  dismiss = output<void>();

  baseUrlControl = new FormControl<string>('https://api.notrack.ai/v1', {
    nonNullable: true,
  });
  modelControl = new FormControl<string>('notrack-uncensored', {
    nonNullable: true,
  });
  apiKeyControl = new FormControl<string>('', { nonNullable: true });

  isTesting = signal<boolean>(false);
  isSaving = signal<boolean>(false);
  testResult = signal<{ notrackOk: boolean; statusMessage: string; latencyMs?: number } | null>(
    null
  );

  ngOnInit() {
    const cfg = this.chatState.config();
    this.baseUrlControl.setValue(cfg.baseUrl);
    this.modelControl.setValue(cfg.model);
  }

  async runConnectionTest() {
    this.isTesting.set(true);
    this.testResult.set(null);
    try {
      const res = await this.notrack.testConnection();
      this.testResult.set({
        notrackOk: res.notrackOk,
        statusMessage: res.statusMessage,
        latencyMs: res.latencyMs,
      });
      this.chatState.diagnosticData.set(res);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'فشل الاتصال';
      this.testResult.set({
        notrackOk: false,
        statusMessage: msg,
      });
    } finally {
      this.isTesting.set(false);
    }
  }

  async saveConfig() {
    const rawUrl = this.baseUrlControl.value;
    const urlValidation = validateApiUrl(rawUrl, true);
    if (!urlValidation.valid) {
      alert(urlValidation.error);
      return;
    }

    this.isSaving.set(true);
    try {
      const payload: { baseUrl?: string; model?: string; apiKey?: string } = {
        baseUrl: urlValidation.sanitizedUrl,
        model: this.modelControl.value.trim(),
      };
      const keyVal = this.apiKeyControl.value.trim();
      if (keyVal) {
        payload.apiKey = keyVal;
      }

      await this.notrack.updateConfig(payload);
      await this.chatState.refreshConfig();
      this.apiKeyControl.setValue('');
      this.dismiss.emit();
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'فشل حفظ الإعدادات';
      alert(msg);
    } finally {
      this.isSaving.set(false);
    }
  }

  async resetDefaults() {
    const isAr = this.chatState.language() === 'ar';
    if (
      confirm(
        isAr
          ? 'استعادة الإعدادات الأصلية للنموذج ورابط NoTrack الافتراضي؟'
          : 'Reset to default NoTrack settings?'
      )
    ) {
      await this.notrack.resetConfig();
      await this.chatState.refreshConfig();
      const cfg = this.chatState.config();
      this.baseUrlControl.setValue(cfg.baseUrl);
      this.modelControl.setValue(cfg.model);
      this.apiKeyControl.setValue('');
      this.testResult.set(null);
    }
  }
}
