import {
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  ViewChild,
  computed,
  effect,
  inject,
  signal,
} from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { Composer } from './components/composer';
import { MessageItem } from './components/message-item';
import { HistoryDrawer } from './components/history-drawer';
import { SettingsDialog } from './components/settings-dialog';
import { DiagnosticsModal } from './components/diagnostics-modal';
import { ChatState } from './services/chat-state';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  imports: [
    MatIconModule,
    Composer,
    MessageItem,
    HistoryDrawer,
    SettingsDialog,
    DiagnosticsModal,
  ],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  chatState = inject(ChatState);

  @ViewChild('scrollContainer') scrollContainer?: ElementRef<HTMLDivElement>;

  isHistoryOpen = signal<boolean>(false);
  isSettingsOpen = signal<boolean>(false);
  isDiagnosticsOpen = signal<boolean>(false);

  promptStarters = computed(() => {
    const isAr = this.chatState.language() === 'ar';
    if (isAr) {
      return [
        { text: 'عرّف عن نفسك وما الذي يميزك؟', icon: 'auto_awesome' },
        { text: 'صغ لي رسالة بريد إلكتروني رسمية ولبقة', icon: 'mail_outline' },
        { text: 'حلل فكرة مشروع تقني جديد واذكر تحدياته', icon: 'lightbulb' },
        { text: 'اكتب دالة بلغة TypeScript للتحقق من أمان الروابط', icon: 'code' },
      ];
    }
    return [
      { text: 'Introduce yourself and your capabilities', icon: 'auto_awesome' },
      { text: 'Draft a professional executive summary', icon: 'mail_outline' },
      { text: 'Analyze key architectural trade-offs in serverless apps', icon: 'lightbulb' },
      { text: 'Write a TypeScript utility with SSRF protection', icon: 'code' },
    ];
  });

  constructor() {
    // Scroll down automatically when new tokens arrive or message count changes
    effect(() => {
      this.chatState.currentMessages();

      setTimeout(() => {
        if (this.scrollContainer?.nativeElement) {
          const el = this.scrollContainer.nativeElement;
          el.scrollTop = el.scrollHeight;
        }
      }, 30);
    });
  }
}

