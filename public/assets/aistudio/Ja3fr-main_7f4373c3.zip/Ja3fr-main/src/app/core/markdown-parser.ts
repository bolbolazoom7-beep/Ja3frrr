/**
 * Safe markdown parser for Ja3far AI chat bubbles.
 * Escapes raw HTML first to prevent XSS, then processes markdown constructs.
 */

export interface CodeBlockData {
  id: string;
  language: string;
  code: string;
}

export function escapeHtml(str: string): string {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

export function parseMarkdown(text: string): string {
  if (!text) return '';

  // 1. Separate code blocks to protect their exact content
  const codeBlocks: { placeholder: string; html: string }[] = [];
  let blockCounter = 0;

  let processed = text.replace(/```([a-zA-Z0-9_-]*)\n([\s\S]*?)```/g, (_, lang, code) => {
    const language = (lang || 'text').trim();
    const escapedCode = escapeHtml(code.trimEnd());
    const placeholder = `%%CODE_BLOCK_${blockCounter++}%%`;
    const blockHtml = `
<div class="my-3 rounded-xl overflow-hidden border border-white/10 bg-[#16161D] text-left" dir="ltr">
  <div class="flex items-center justify-between px-3.5 py-1.5 bg-[#1F1F28] border-b border-white/5 text-xs text-[#A6A2B3]">
    <span class="font-mono font-medium">${escapeHtml(language)}</span>
    <button type="button" class="copy-code-btn inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] hover:text-white hover:bg-white/10 transition-colors" data-code="${encodeURIComponent(code.trimEnd())}">
      <span class="material-icons text-sm" style="font-size: 13px;">content_copy</span>
      <span>نسخ</span>
    </button>
  </div>
  <pre class="p-3.5 text-xs font-mono overflow-x-auto text-[#E6E4EC] leading-relaxed"><code>${escapedCode}</code></pre>
</div>`;
    codeBlocks.push({ placeholder, html: blockHtml });
    return placeholder;
  });

  // 2. Escape any remaining HTML to prevent script injection
  processed = escapeHtml(processed);

  // 3. Process inline code `code`
  processed = processed.replace(/`([^`]+)`/g, (_, code) => {
    return `<code class="px-1.5 py-0.5 mx-0.5 rounded bg-white/10 text-[#A994F7] font-mono text-xs">${code}</code>`;
  });

  // 4. Headers (#, ##, ###)
  processed = processed.replace(/^### (.*$)/gim, '<h4 class="text-sm font-semibold text-[#8BCFC2] mt-3 mb-1.5">$1</h4>');
  processed = processed.replace(/^## (.*$)/gim, '<h3 class="text-base font-semibold text-[#A994F7] mt-3.5 mb-2">$1</h3>');
  processed = processed.replace(/^# (.*$)/gim, '<h2 class="text-lg font-bold text-white mt-4 mb-2.5">$1</h2>');

  // 5. Bold & Italic
  processed = processed.replace(/\*\*([^*]+)\*\*/g, '<strong class="font-semibold text-white">$1</strong>');
  processed = processed.replace(/\*([^*]+)\*/g, '<em class="italic text-[#E6E4EC]">$1</em>');

  // 6. Blockquotes
  processed = processed.replace(/^> (.*$)/gim, '<blockquote class="border-r-2 border-[#A994F7] pr-3 my-2 text-sm text-[#A6A2B3] italic">$1</blockquote>');

  // 7. Bullet lists (- item or * item)
  processed = processed.replace(/^\s*[-*]\s+(.*)$/gim, '<li class="my-0.5 text-sm list-disc list-inside">$1</li>');

  // 8. Numbered lists (1. item)
  processed = processed.replace(/^\s*(\d+)\.\s+(.*)$/gim, '<li class="my-0.5 text-sm list-decimal list-inside">$2</li>');

  // 9. Line breaks and paragraphs
  processed = processed.replace(/\n\n+/g, '</p><p class="my-2">');
  processed = processed.replace(/\n/g, '<br/>');

  // 10. Restore code blocks
  for (const block of codeBlocks) {
    processed = processed.replace(block.placeholder, block.html);
  }

  return `<p class="leading-relaxed text-sm md:text-base">${processed}</p>`;
}
