export type Role = 'user' | 'assistant' | 'system';

export type MessageStatus = 'sending' | 'streaming' | 'complete' | 'error';

export type ErrorCategory =
  | 'CONFIGURATION_ERROR'
  | 'AUTHENTICATION_ERROR'
  | 'AUTHORIZATION_ERROR'
  | 'PROVIDER_ERROR'
  | 'RATE_LIMIT'
  | 'QUOTA_OR_BILLING_ERROR'
  | 'NETWORK_ERROR'
  | 'TIMEOUT_ERROR'
  | 'BACKEND_ERROR'
  | 'STORAGE_ERROR'
  | 'DEPLOYMENT_ERROR'
  | 'VALIDATION_ERROR'
  | 'UNSUPPORTED_CAPABILITY'
  | 'UNKNOWN_ERROR';

export interface ChatMessage {
  id: string;
  role: Role;
  content: string;
  timestamp: number;
  status: MessageStatus;
  errorCategory?: ErrorCategory;
  errorMessage?: string;
  tokenCount?: number;
}

export interface Conversation {
  id: string;
  title: string;
  createdAt: number;
  updatedAt: number;
  messages: ChatMessage[];
}

export interface NoTrackConfig {
  baseUrl: string;
  model: string;
  apiKeyMasked: string;
  isCustomConfigured: boolean;
  status: 'connected' | 'not_configured' | 'error' | 'testing';
  lastChecked?: number;
  lastLatencyMs?: number;
}

export interface DiagnosticResult {
  frontendOk: boolean;
  backendOk: boolean;
  notrackOk: boolean;
  latencyMs?: number;
  statusMessage: string;
  category?: ErrorCategory;
  timestamp: number;
  activeModel: string;
  version: string;
}

export type AppTheme = 'dark' | 'light' | 'system';
export type AppLanguage = 'ar' | 'en';
