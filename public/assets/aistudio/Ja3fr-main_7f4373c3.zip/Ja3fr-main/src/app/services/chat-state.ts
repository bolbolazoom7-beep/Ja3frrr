import { Injectable, inject, signal, computed, effect } from '@angular/core';
import {
  AppLanguage,
  AppTheme,
  ChatMessage,
  Conversation,
  DiagnosticResult,
  NoTrackConfig,
} from '../core/types';
import { NoTrackClient } from './notrack';
import { classifyError, normalizeError } from '../core/error-handler';

const STORAGE_KEY_CONVERSATIONS = 'ja3far_conversations_v1';
const STORAGE_KEY_SETTINGS = 'ja3far_settings_v1';

@Injectable({
  providedIn: 'root',
})
export class ChatState {
  private notrack = inject(NoTrackClient);

  // Core signals
  conversations = signal<Conversation[]>([]);
  currentConversationId = signal<string | null>(null);
  isStreaming = signal<boolean>(false);
  isLoading = signal<boolean>(false);
  searchQuery = signal<string>('');
  theme = signal<AppTheme>('dark');
  language = signal<AppLanguage>('ar');

  config = signal<NoTrackConfig>({
    baseUrl: 'https://api.notrack.ai/v1',
    model: 'notrack-uncensored',
    apiKeyMasked: '',
    isCustomConfigured: false,
    status: 'connected',
  });

  diagnosticData = signal<DiagnosticResult | null>(null);

  private currentAbortController: AbortController | null = null;

  // Computed signals
  activeConversation = computed(() => {
    const id = this.currentConversationId();
    if (!id) return null;
    return this.conversations().find((c) => c.id === id) || null;
  });

  currentMessages = computed(() => {
    return this.activeConversation()?.messages || [];
  });

  filteredConversations = computed(() => {
    const q = this.searchQuery().trim().toLowerCase();
    const list = this.conversations();
    if (!q) return list;
    return list.filter(
      (c) =>
        c.title.toLowerCase().includes(q) ||
        c.messages.some((m) => m.content.toLowerCase().includes(q))
    );
  });

  constructor() {
    this.loadStateFromStorage();
    this.refreshConfig();

    // Auto-save changes to localStorage
    effect(() => {
      const convs = this.conversations();
      if (typeof window !== 'undefined' && window.localStorage) {
        try {
          localStorage.setItem(STORAGE_KEY_CONVERSATIONS, JSON.stringify(convs));
        } catch {
          // ignore storage quota error
        }
      }
    });

    effect(() => {
      const th = this.theme();
      const lang = this.language();
      if (typeof window !== 'undefined' && window.localStorage) {
        try {
          localStorage.setItem(
            STORAGE_KEY_SETTINGS,
            JSON.stringify({ theme: th, language: lang })
          );
        } catch {
          // ignore
        }
      }
      this.applyThemeAndLanguage(th, lang);
    });
  }

  private loadStateFromStorage() {
    if (typeof window === 'undefined' || !window.localStorage) return;

    try {
      const savedSettings = localStorage.getItem(STORAGE_KEY_SETTINGS);
      if (savedSettings) {
        const parsed = JSON.parse(savedSettings);
        if (parsed.theme) this.theme.set(parsed.theme);
        if (parsed.language) this.language.set(parsed.language);
      }

      const savedConvs = localStorage.getItem(STORAGE_KEY_CONVERSATIONS);
      if (savedConvs) {
        const parsedConvs: Conversation[] = JSON.parse(savedConvs);
        if (Array.isArray(parsedConvs) && parsedConvs.length > 0) {
          this.conversations.set(parsedConvs);
          this.currentConversationId.set(parsedConvs[0].id);
        }
      }
    } catch {
      // Fallback cleanly
    }
  }

  private applyThemeAndLanguage(theme: AppTheme, lang: AppLanguage) {
    if (typeof document === 'undefined') return;

    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';

    const isDark =
      theme === 'dark' ||
      (theme === 'system' &&
        window.matchMedia?.('(prefers-color-scheme: dark)').matches);

    if (isDark) {
      document.documentElement.classList.add('dark');
      document.documentElement.classList.remove('light');
      document.body.style.backgroundColor = '#111116';
      document.body.style.color = '#E6E4EC';
    } else {
      document.documentElement.classList.add('light');
      document.documentElement.classList.remove('dark');
      document.body.style.backgroundColor = '#F6F3EE';
      document.body.style.color = '#1A1821';
    }
  }

  async refreshConfig() {
    try {
      const cfg = await this.notrack.getConfig();
      this.config.set(cfg);
    } catch {
      // ignore
    }
  }

  startNewConversation(): string {
    const id = `conv_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const newConv: Conversation = {
      id,
      title: this.language() === 'ar' ? 'محادثة جديدة' : 'New Chat',
      createdAt: Date.now(),
      updatedAt: Date.now(),
      messages: [],
    };

    this.conversations.update((prev) => [newConv, ...prev]);
    this.currentConversationId.set(id);
    return id;
  }

  selectConversation(id: string) {
    this.currentConversationId.set(id);
  }

  renameConversation(id: string, newTitle: string) {
    const trimmed = newTitle.trim();
    if (!trimmed) return;
    this.conversations.update((list) =>
      list.map((c) => (c.id === id ? { ...c, title: trimmed, updatedAt: Date.now() } : c))
    );
  }

  deleteConversation(id: string) {
    this.conversations.update((list) => list.filter((c) => c.id !== id));
    if (this.currentConversationId() === id) {
      const remaining = this.conversations();
      this.currentConversationId.set(remaining.length > 0 ? remaining[0].id : null);
    }
  }

  clearAllConversations() {
    this.conversations.set([]);
    this.currentConversationId.set(null);
  }

  stopStreaming() {
    if (this.currentAbortController) {
      this.currentAbortController.abort();
      this.currentAbortController = null;
    }
    this.isStreaming.set(false);
    this.isLoading.set(false);
  }

  async sendMessage(userText: string) {
    const text = userText.trim();
    if (!text || this.isStreaming()) return;

    let convId = this.currentConversationId();
    if (!convId) {
      convId = this.startNewConversation();
    }

    const userMessage: ChatMessage = {
      id: `msg_u_${Date.now()}`,
      role: 'user',
      content: text,
      timestamp: Date.now(),
      status: 'complete',
    };

    const assistantMessageId = `msg_a_${Date.now()}`;
    const assistantMessage: ChatMessage = {
      id: assistantMessageId,
      role: 'assistant',
      content: '',
      timestamp: Date.now(),
      status: 'streaming',
    };

    // Update conversation title if it's the first message
    const currentConv = this.activeConversation();
    const shouldUpdateTitle = !currentConv || currentConv.messages.length === 0;
    const newTitle = shouldUpdateTitle
      ? text.length > 28
        ? text.substring(0, 28) + '...'
        : text
      : currentConv.title;

    this.conversations.update((list) =>
      list.map((c) => {
        if (c.id === convId) {
          return {
            ...c,
            title: newTitle,
            updatedAt: Date.now(),
            messages: [...c.messages, userMessage, assistantMessage],
          };
        }
        return c;
      })
    );

    this.isStreaming.set(true);
    this.isLoading.set(true);
    this.currentAbortController = new AbortController();

    // Prepare payload context
    const messagesPayload = (this.activeConversation()?.messages || [])
      .filter((m) => m.id !== assistantMessageId && m.status !== 'error')
      .map((m) => ({ role: m.role, content: m.content }));

    let streamedAccumulator = '';

    await this.notrack.streamChat(
      messagesPayload,
      {
        onToken: (token) => {
          this.isLoading.set(false);
          streamedAccumulator += token;

          this.conversations.update((list) =>
            list.map((c) => {
              if (c.id === convId) {
                return {
                  ...c,
                  messages: c.messages.map((m) =>
                    m.id === assistantMessageId
                      ? { ...m, content: streamedAccumulator }
                      : m
                  ),
                };
              }
              return c;
            })
          );
        },
        onComplete: () => {
          this.isStreaming.set(false);
          this.isLoading.set(false);
          this.currentAbortController = null;

          this.conversations.update((list) =>
            list.map((c) => {
              if (c.id === convId) {
                return {
                  ...c,
                  messages: c.messages.map((m) =>
                    m.id === assistantMessageId
                      ? { ...m, status: 'complete' }
                      : m
                  ),
                };
              }
              return c;
            })
          );
        },
        onError: (err) => {
          this.isStreaming.set(false);
          this.isLoading.set(false);
          this.currentAbortController = null;

          const category = classifyError(undefined, err);
          const normalized = normalizeError(category, this.language());

          this.conversations.update((list) =>
            list.map((c) => {
              if (c.id === convId) {
                return {
                  ...c,
                  messages: c.messages.map((m) =>
                    m.id === assistantMessageId
                      ? {
                          ...m,
                          status: 'error',
                          errorCategory: category,
                          errorMessage: `${normalized.message} (${normalized.recoveryAction})`,
                        }
                      : m
                  ),
                };
              }
              return c;
            })
          );
        },
      },
      this.currentAbortController.signal
    );
  }

  async regenerateResponse(assistantMessageId: string) {
    if (this.isStreaming()) return;
    const conv = this.activeConversation();
    if (!conv) return;

    const msgIdx = conv.messages.findIndex((m) => m.id === assistantMessageId);
    if (msgIdx <= 0) return;

    // Remove the failed or old assistant message and all subsequent messages
    const trimmedMessages = conv.messages.slice(0, msgIdx);
    const lastUserMsg = trimmedMessages[trimmedMessages.length - 1];
    if (!lastUserMsg || lastUserMsg.role !== 'user') return;

    this.conversations.update((list) =>
      list.map((c) => (c.id === conv.id ? { ...c, messages: trimmedMessages } : c))
    );

    await this.sendMessage(lastUserMsg.content);
  }

  async editAndResend(userMessageId: string, newContent: string) {
    if (this.isStreaming()) return;
    const conv = this.activeConversation();
    if (!conv) return;

    const msgIdx = conv.messages.findIndex((m) => m.id === userMessageId);
    if (msgIdx < 0) return;

    // Trim everything after this message
    const trimmed = conv.messages.slice(0, msgIdx);
    this.conversations.update((list) =>
      list.map((c) => (c.id === conv.id ? { ...c, messages: trimmed } : c))
    );

    await this.sendMessage(newContent);
  }

  setTheme(th: AppTheme) {
    this.theme.set(th);
  }

  setLanguage(lang: AppLanguage) {
    this.language.set(lang);
  }

  exportDataJson(): string {
    return JSON.stringify(
      {
        version: '1.0',
        exportedAt: new Date().toISOString(),
        conversations: this.conversations(),
      },
      null,
      2
    );
  }

  importDataJson(rawJson: string): boolean {
    try {
      const data = JSON.parse(rawJson);
      if (Array.isArray(data.conversations)) {
        this.conversations.set(data.conversations);
        if (data.conversations.length > 0) {
          this.currentConversationId.set(data.conversations[0].id);
        }
        return true;
      }
      return false;
    } catch {
      return false;
    }
  }
}
