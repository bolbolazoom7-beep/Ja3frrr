import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import { DiagnosticResult, NoTrackConfig } from '../core/types';

export interface StreamCallbacks {
  onToken: (token: string) => void;
  onComplete: () => void;
  onError: (error: string) => void;
}

interface ServerConfigResponse {
  baseUrl?: string;
  model?: string;
  apiKeyMasked?: string;
  isCustomKey?: boolean;
  isConfigured?: boolean;
}

interface ServerDiagnosticsResponse {
  success?: boolean;
  message?: string;
  activeModel?: string;
  latencyMs?: number;
  availableModels?: string[];
}

@Injectable({
  providedIn: 'root',
})
export class NoTrackClient {
  private http = inject(HttpClient);

  async getConfig(): Promise<NoTrackConfig> {
    try {
      const res = await firstValueFrom(
        this.http.get<ServerConfigResponse>('/api/config')
      );
      return {
        baseUrl: res.baseUrl || 'https://api.notrack.ai/v1',
        model: res.model || 'notrack-uncensored',
        apiKeyMasked: res.apiKeyMasked || '',
        isCustomConfigured: !!res.isCustomKey,
        status: res.isConfigured ? 'connected' : 'not_configured',
      };
    } catch {
      return {
        baseUrl: 'https://api.notrack.ai/v1',
        model: 'notrack-uncensored',
        apiKeyMasked: '',
        isCustomConfigured: false,
        status: 'error',
      };
    }
  }

  async updateConfig(params: {
    apiKey?: string;
    baseUrl?: string;
    model?: string;
  }): Promise<Record<string, unknown>> {
    return firstValueFrom(
      this.http.post<Record<string, unknown>>('/api/config', params)
    );
  }

  async resetConfig(): Promise<Record<string, unknown>> {
    return firstValueFrom(
      this.http.post<Record<string, unknown>>('/api/config/reset', {})
    );
  }

  async testConnection(): Promise<DiagnosticResult> {
    const startTime = Date.now();
    try {
      const res = await firstValueFrom(
        this.http.post<ServerDiagnosticsResponse>(
          '/api/diagnostics/test-connection',
          {}
        )
      );
      return {
        frontendOk: true,
        backendOk: true,
        notrackOk: true,
        latencyMs: res.latencyMs || Date.now() - startTime,
        statusMessage: res.message || 'تم التحقق من الاتصال بنجاح',
        activeModel: res.activeModel || 'notrack-uncensored',
        timestamp: Date.now(),
        version: '1.0.0-ja3far',
      };
    } catch (err: unknown) {
      const latencyMs = Date.now() - startTime;
      const errorObj = err as {
        status?: number;
        error?: { message?: string; errorCategory?: import('../core/types').ErrorCategory };
        message?: string;
      };
      const errorMsg =
        errorObj.error?.message || errorObj.message || 'فشل الاتصال بـ NoTrack.ai';
      return {
        frontendOk: true,
        backendOk: errorObj.status !== 0 && errorObj.status !== 504,
        notrackOk: false,
        latencyMs,
        statusMessage: errorMsg,
        category: errorObj.error?.errorCategory || 'NETWORK_ERROR',
        activeModel: 'notrack-uncensored',
        timestamp: Date.now(),
        version: '1.0.0-ja3far',
      };
    }
  }

  async streamChat(
    messages: { role: string; content: string }[],
    callbacks: StreamCallbacks,
    abortSignal?: AbortSignal
  ): Promise<void> {
    try {
      const response = await fetch('/api/chat/stream', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ messages }),
        signal: abortSignal,
      });

      if (!response.ok) {
        let errDetail = 'خطأ في استجابة الخادم';
        try {
          const json = await response.json();
          errDetail = json.error || json.message || errDetail;
        } catch {
          // ignore
        }
        callbacks.onError(errDetail);
        return;
      }

      const reader = response.body?.getReader();
      if (!reader) {
        callbacks.onError('تعذر قراءة تدفق البيانات');
        return;
      }

      const decoder = new TextDecoder();
      let buffer = '';

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() || '';

        for (const line of lines) {
          const trimmed = line.trim();
          if (!trimmed.startsWith('data: ')) continue;
          const payload = trimmed.slice(6).trim();

          if (payload === '[DONE]') {
            callbacks.onComplete();
            return;
          }

          if (payload.startsWith('[ERROR]')) {
            callbacks.onError(payload.slice(7).trim());
            return;
          }

          try {
            const parsed = JSON.parse(payload);
            const content = parsed.choices?.[0]?.delta?.content;
            if (content) {
              callbacks.onToken(content);
            }
          } catch {
            // Ignore partial SSE tokens
          }
        }
      }

      callbacks.onComplete();
    } catch (err: unknown) {
      if (abortSignal?.aborted) {
        callbacks.onComplete();
        return;
      }
      const message = err instanceof Error ? err.message : 'انقطع الاتصال بالخادم';
      callbacks.onError(message);
    }
  }
}
