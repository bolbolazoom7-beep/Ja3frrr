import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express, { Request, Response } from 'express';
import { join } from 'node:path';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
const angularApp = new AngularNodeAppEngine();

// Parse JSON bodies with reasonable limit
app.use(express.json({ limit: '2mb' }));

// NoTrack.ai Configuration State (protected server-side)
const DEFAULT_API_KEY =
  process.env['NOTRACK_API_KEY'] ||
  'sk-notrack-fbdd27780cdb50aa10134a0d069d5f183433217819bf8572';

let activeApiKey = DEFAULT_API_KEY;
let activeBaseUrl = (
  process.env['NOTRACK_BASE_URL'] || 'https://api.notrack.ai/v1'
).replace(/\/+$/, '');
let activeModel = process.env['NOTRACK_MODEL'] || 'notrack-uncensored';

function maskApiKey(key: string): string {
  if (!key) return '';
  if (key.length <= 12) return '***';
  return `${key.slice(0, 10)}...${key.slice(-4)}`;
}

function isValidUrl(rawUrl: string): boolean {
  try {
    const url = new URL(rawUrl);
    if (url.protocol !== 'https:' && url.protocol !== 'http:') return false;
    if (url.username || url.password) return false;
    const hostname = url.hostname.toLowerCase();
    // Block private/loopback/cloud metadata IP ranges
    if (
      hostname === 'localhost' ||
      hostname === '127.0.0.1' ||
      hostname === '0.0.0.0' ||
      hostname === '::1' ||
      hostname.startsWith('10.') ||
      hostname.startsWith('192.168.') ||
      hostname.startsWith('169.254.')
    ) {
      return false;
    }
    return true;
  } catch {
    return false;
  }
}

// ==========================================
// REST API ROUTES
// ==========================================

// 1. Health Endpoint
app.get('/api/health', (_req: Request, res: Response) => {
  res.json({
    status: 'ok',
    timestamp: Date.now(),
    service: 'Ja3far AI Backend',
    hasApiKey: !!activeApiKey,
    model: activeModel,
  });
});

// 2. Config Endpoint (masked secrets only)
app.get('/api/config', (_req: Request, res: Response) => {
  res.json({
    baseUrl: activeBaseUrl,
    model: activeModel,
    apiKeyMasked: maskApiKey(activeApiKey),
    isConfigured: !!activeApiKey,
    isCustomKey: activeApiKey !== DEFAULT_API_KEY,
  });
});

// 3. Update Configuration
app.post('/api/config', (req: Request, res: Response) => {
  const { apiKey, baseUrl, model } = req.body;

  if (baseUrl) {
    if (!isValidUrl(baseUrl)) {
      res.status(400).json({
        error: 'عنوان URL غير صالح أو يمثل نطاقاً داخلياً محظوراً (SSRF protection).',
      });
      return;
    }
    activeBaseUrl = baseUrl.trim().replace(/\/+$/, '');
  }

  if (typeof apiKey === 'string' && apiKey.trim().length > 0) {
    activeApiKey = apiKey.trim();
  }

  if (typeof model === 'string' && model.trim().length > 0) {
    activeModel = model.trim();
  }

  res.json({
    success: true,
    message: 'تم تحديث الإعدادات بنجاح.',
    baseUrl: activeBaseUrl,
    model: activeModel,
    apiKeyMasked: maskApiKey(activeApiKey),
  });
});

// 4. Reset Configuration to default
app.post('/api/config/reset', (_req: Request, res: Response) => {
  activeApiKey = DEFAULT_API_KEY;
  activeBaseUrl = 'https://api.notrack.ai/v1';
  activeModel = 'notrack-uncensored';

  res.json({
    success: true,
    message: 'تمت استعادة الإعدادات الافتراضية بنجاح.',
    baseUrl: activeBaseUrl,
    model: activeModel,
    apiKeyMasked: maskApiKey(activeApiKey),
  });
});

// 5. Diagnostics - Test Connection
app.post('/api/diagnostics/test-connection', async (_req: Request, res: Response) => {
  if (!activeApiKey) {
    res.status(400).json({
      success: false,
      errorCategory: 'CONFIGURATION_ERROR',
      message: 'لم يتم تكوين مفتاح NoTrack API.',
    });
    return;
  }

  const startTime = Date.now();
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 12000);

    const targetUrl = `${activeBaseUrl}/models`;
    const response = await fetch(targetUrl, {
      method: 'GET',
      headers: {
        Authorization: `Bearer ${activeApiKey}`,
        Accept: 'application/json',
      },
      signal: controller.signal,
    });

    clearTimeout(timeout);
    const latencyMs = Date.now() - startTime;

    if (!response.ok) {
      const errText = await response.text();
      let parsedErr = errText;
      try {
        const json = JSON.parse(errText);
        parsedErr = json.error?.message || json.message || errText;
      } catch {
        // use raw
      }

      res.status(response.status).json({
        success: false,
        statusCode: response.status,
        latencyMs,
        message: `استجاب المزود برمز خطأ ${response.status}: ${parsedErr}`,
      });
      return;
    }

    const data = await response.json();
    const modelsList = Array.isArray(data?.data)
      ? data.data.map((m: { id: string }) => m.id)
      : [activeModel];

    res.json({
      success: true,
      statusCode: 200,
      latencyMs,
      endpoint: activeBaseUrl,
      activeModel,
      availableModels: modelsList,
      message: 'تم التحقق من الاتصال بنجاح مع NoTrack.ai!',
    });
  } catch (err: unknown) {
    const latencyMs = Date.now() - startTime;
    const message = err instanceof Error ? err.message : String(err);
    const isTimeout = /abort|timeout/i.test(message);

    res.status(isTimeout ? 504 : 502).json({
      success: false,
      statusCode: isTimeout ? 504 : 502,
      latencyMs,
      errorCategory: isTimeout ? 'TIMEOUT_ERROR' : 'NETWORK_ERROR',
      message: `فشل الاتصال بـ NoTrack: ${message}`,
    });
  }
});

// 6. Chat Endpoint (Non-streaming)
app.post('/api/chat', async (req: Request, res: Response) => {
  const { messages, temperature = 0.7, max_tokens = 2048 } = req.body;

  if (!Array.isArray(messages) || messages.length === 0) {
    res.status(400).json({
      error: 'قائمة الرسائل مطلوبة (Array of messages).',
    });
    return;
  }

  if (!activeApiKey) {
    res.status(401).json({
      errorCategory: 'AUTHENTICATION_ERROR',
      error: 'مفتاح NoTrack API غير مهيأ.',
    });
    return;
  }

  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 60000);

    const response = await fetch(`${activeBaseUrl}/chat/completions`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${activeApiKey}`,
      },
      body: JSON.stringify({
        model: activeModel,
        messages: messages.map((m: { role: string; content: string }) => ({
          role: m.role,
          content: m.content,
        })),
        temperature,
        max_tokens,
        stream: false,
      }),
      signal: controller.signal,
    });

    clearTimeout(timeout);

    if (!response.ok) {
      const errText = await response.text();
      res.status(response.status).json({
        statusCode: response.status,
        rawError: errText,
        error: `خطأ من NoTrack (${response.status})`,
      });
      return;
    }

    const data = await response.json();
    const assistantMessage = data.choices?.[0]?.message?.content || '';

    res.json({
      id: data.id || `msg_${Date.now()}`,
      role: 'assistant',
      content: assistantMessage,
      model: data.model || activeModel,
      usage: data.usage,
    });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : String(err);
    res.status(500).json({
      errorCategory: 'NETWORK_ERROR',
      error: `فشل الطلب: ${message}`,
    });
  }
});

// 7. Chat Streaming Endpoint (SSE)
app.post('/api/chat/stream', async (req: Request, res: Response) => {
  const { messages, temperature = 0.7, max_tokens = 2048 } = req.body;

  if (!Array.isArray(messages) || messages.length === 0) {
    res.status(400).json({ error: 'قائمة الرسائل مطلوبة.' });
    return;
  }

  if (!activeApiKey) {
    res.status(401).json({
      errorCategory: 'AUTHENTICATION_ERROR',
      error: 'مفتاح NoTrack API غير مهيأ.',
    });
    return;
  }

  const abortController = new AbortController();

  res.on('close', () => {
    if (!res.writableEnded) {
      abortController.abort();
    }
  });

  try {
    const response = await fetch(`${activeBaseUrl}/chat/completions`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${activeApiKey}`,
      },
      body: JSON.stringify({
        model: activeModel,
        messages: messages.map((m: { role: string; content: string }) => ({
          role: m.role,
          content: m.content,
        })),
        temperature,
        max_tokens,
        stream: true,
      }),
      signal: abortController.signal,
    });

    if (!response.ok) {
      const errText = await response.text();
      res.status(response.status).json({
        statusCode: response.status,
        error: `خطأ من NoTrack: ${response.statusText}`,
        raw: errText,
      });
      return;
    }

    // Set Server-Sent Events headers
    res.setHeader('Content-Type', 'text/event-stream; charset=utf-8');
    res.setHeader('Cache-Control', 'no-cache, no-transform');
    res.setHeader('Connection', 'keep-alive');
    res.setHeader('X-Accel-Buffering', 'no');
    res.flushHeaders?.();

    if (!response.body) {
      res.write('data: [ERROR] No response body\n\n');
      res.end();
      return;
    }

    for await (const chunk of response.body as any) {
      if (abortController.signal.aborted) {
        break;
      }
      res.write(chunk);
    }

    res.end();
  } catch (err: unknown) {
    if (abortController.signal.aborted) {
      // Client cancelled stream
      res.end();
      return;
    }
    const message = err instanceof Error ? err.message : String(err);
    if (!res.headersSent) {
      res.status(500).json({ error: message });
    } else {
      res.write(`data: [ERROR] ${message}\n\n`);
      res.end();
    }
  }
});

// ==========================================
// STATIC FILES & SSR CATCH-ALL
// ==========================================

app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, (error) => {
    if (error) {
      throw error;
    }
    console.log(`Ja3far AI server listening on http://localhost:${port}`);
  });
}

export const reqHandler = createNodeRequestHandler(app);

